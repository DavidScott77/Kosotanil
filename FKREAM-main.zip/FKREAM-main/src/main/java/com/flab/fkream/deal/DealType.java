package com.flab.fkream.deal;

public enum DealType {
    PURCHASE, SALE
}
