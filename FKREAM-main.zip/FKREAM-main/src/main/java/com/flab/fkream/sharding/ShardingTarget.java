package com.flab.fkream.sharding;

public enum ShardingTarget {
    ADDRESS
}
