package com.flab.fkream.notification;

import org.springframework.stereotype.Service;

@Service
public class NotificationService {
}
