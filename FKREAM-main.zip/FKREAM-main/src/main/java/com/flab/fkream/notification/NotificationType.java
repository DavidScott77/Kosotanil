package com.flab.fkream.notification;

public enum NotificationType {
    CHANGED_PRICE_OF_INTERESTED_ITEM, UPDATE_STATE_OF_ITEM
}
