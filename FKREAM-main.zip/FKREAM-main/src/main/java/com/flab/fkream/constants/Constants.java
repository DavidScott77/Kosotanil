package com.flab.fkream.constants;

public class Constants {

    public static final String ShardDelimiter = "|";

}
