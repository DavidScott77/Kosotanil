package com.flab.fkream.item;

public enum ItemGender {
    MALE, FEMALE, KIDS
}
