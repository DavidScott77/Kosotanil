package com.flab.fkream.sharding;

public enum ShardingStrategy {
    RANGE, MODULAR
}
