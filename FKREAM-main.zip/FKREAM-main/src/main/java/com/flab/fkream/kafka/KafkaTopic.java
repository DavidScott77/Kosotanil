package com.flab.fkream.kafka;

public class KafkaTopic {

    public static final String ITEM_TOPIC = "item";
    public static final String SEARCH_LOG = "search_log";
    public static final String DEAL = "deal";
    public static final String ITEM_PURCHASE_PRICE = "item_purchase_price";
}
