package com.flab.fkream.search;

public enum SortCriteria {
    POPULAR, PREMIUM_DESC, PREMIUM_ASC, LOWEST_SELLING_PRICE, HIGHEST_PURCHASE_PRICE, RELEASE_DATE
}
