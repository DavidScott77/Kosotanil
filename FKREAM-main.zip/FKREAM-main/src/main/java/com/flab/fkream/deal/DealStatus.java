package com.flab.fkream.deal;

public enum DealStatus {
    BIDDING, IMMEDIATE, PROGRESS, CANCEL, COMPLETION,
}
