package com.flab.fkream.search;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class TrieTest {

//    Trie trie = new Trie();
//
//    @Test
//    void search() {
//        trie.insert("사과");
//        trie.insert("바나나");
//        trie.insert("체리");
//        trie.insert("두리안");
//
//        trie.insert("사과원");
//        trie.insert("바나나원");
//        trie.insert("체리원");
//        trie.insert("두리안원");
//
//        trie.insert("사과투");
//        trie.insert("바나나투");
//        trie.insert("체리투");
//        trie.insert("두리안투");
//
//        trie.insert("사과원투");
//        trie.insert("사과원쓰리");
//        trie.insert("사과원포");
//        trie.insert("사과원투수");
//        trie.insert("사과투포");
//        trie.insert("사과투쓰리");
//        trie.insert("사과투포파이브");
//
//        assertThat(trie.search("사과원")).contains("사과원투수").hasSize(5);
//    }
}